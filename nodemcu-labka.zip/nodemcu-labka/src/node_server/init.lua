-- init.lua --

--require ( "utils_test" )
-- require ( "test" )

require ( "ext_wifi" )

wifiInit()

dofile ( "httpd.lua" )
--dofile ( "irc.lua" )

