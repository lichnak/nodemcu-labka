-- init.lua --

-- Global Variables (most of the time keep it empty)

-- Run the httpd file
dofile("httpd.lua")