# nodemcu-labka

Labka.cz nodeMCU project owned by lichnak and PeterBay


[cs]https://labka.cz/wiki/doku.php?id=project:nodemcu

[en]https://labka.cz/wiki/doku.php?id=project:nodemcu:en
