--wifiSSID="HNetwork"
--wifiPassword="HomeNetwork5520"

wifiSSID="SIT_Guest"
wifiPassword="Ostrava2015"
