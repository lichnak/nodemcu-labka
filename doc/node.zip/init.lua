-- init.lua --

require ( "ext_wifi" )
wifiInit()

dofile ( "httpd.lua" )
